// Assignment 4 - Question 2 Menu Print Function File
// Prints out menu 
// PROG71985 - 22F - Sec2 - Programming Principles
// Ryan Tu - Fall November 2022
// Version 1.0

#include <stdio.h>
#include "menuPrint.h"

void menuPrint()
{
	// displays menu
	printf("\na) Add a task\nb) Delete a task\nc) Show list of tasks\n");
	printf("z) Quit\n");
	printf("\n---------------------------");
	printf("\nAction: ");
}
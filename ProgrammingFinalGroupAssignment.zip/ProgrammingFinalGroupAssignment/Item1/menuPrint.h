// Assignment 4 - Question 2 Menu Print Header File
// PROG71985 - 22F - Sec2 - Programming Principles
// Ryan Tu - Fall November 2022
// Version 1.0

#pragma once

void menuPrint();

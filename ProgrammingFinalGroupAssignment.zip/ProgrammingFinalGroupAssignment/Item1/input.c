// Assignment 4 - Question 2 Input Function File
// Asks for user input letter 
// PROG71985 - 22F - Sec2 - Programming Principles
// Ryan Tu - Fall November 2022
// Version 1.0

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include "input.h"

void userInputFunction(char* userInput)
{
	scanf("%c", userInput);
}